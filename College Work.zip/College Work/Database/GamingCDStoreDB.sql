use GamingCDStore
go

create table vendor
(
	vendor_id char(5) primary key,
	vendor_name char(25)
);

insert into vendor values ('Ven01', 'Louise');
insert into vendor values ('Ven02', 'Emma');
insert into vendor values ('Ven03', 'James');
insert into vendor values ('Ven04', 'Caroline');
insert into vendor values ('Ven05', 'Seamus');

create table Division
(
	division_id char(5) primary key,
	division char(25)
);

insert into Division values ('DRace', 'Racing Game');
insert into Division values ('DActG', 'Action Game');
insert into Division values ('DEduG', 'Education Game');
insert into Division values ('DStrG', 'Strategy Game');
insert into Division values ('DSpoG', 'Sports Game');

create table Customer
(
	cust_id char(5) primary key,
	cust_name  char(15),
	cust_gender char(6),
	cust_address varchar (20),
	zipcode char(2)
);

insert into Customer values ('Cus01', 'Abby', 'Female', 'Rathmines', 'D6');
insert into Customer values ('Cus02', 'Raulf', 'Male', 'Ballsbridge', 'D4');
insert into Customer values ('Cus03', 'Aoife', 'Female', 'City Center', 'D1');
insert into Customer values ('Cus04', 'Sean', 'Male', 'Santry', 'D9');
insert into Customer values ('Cus05', 'Finon', 'Male', 'South Circular Road', 'D8');

create table region
(
	region_id char(5) primary key,
	region_name char(20)
);

insert into region values ('Reg01', 'Dublin');
insert into region values ('Reg02', 'Limerick');
insert into region values ('Reg03', 'Cork');
insert into region values ('Reg04', 'Kerry');
insert into region values ('Reg05', 'Waterford');

create table store
(
	store_id char(5) primary key,
	store_zipcode char(5),
	region_id char(5),
	foreign key (region_id) references region
);

insert into store values ('Sto01', 'D2', 'Reg01');
insert into store values ('Sto02', 'W22', 'Reg05');
insert into store values ('Sto03', 'C3', 'Reg03');
insert into store values ('Sto04', 'L12', 'Reg02');
insert into store values ('Sto05', 'D8', 'Reg01');

create table SalesTransactions
(
	trans_id char(5) primary key,
	trans_date date,
	store_id char(5),
	foreign key (store_id) references store,
	cust_id char(5),
	foreign key (cust_id) references Customer,
	month char(20)
);

insert into SalesTransactions values ('STr01', '08-05-2012', 'Sto01', 'Cus03', 'Dec');
insert into SalesTransactions values ('STr02', '05-05-2015', 'Sto05', 'Cus05', 'Jan');
insert into SalesTransactions values ('STr03', '09-01-2015', 'Sto03', 'Cus01', 'June');
insert into SalesTransactions values ('STr04', '12-05-2013', 'Sto04', 'Cus02', 'Oct');
insert into SalesTransactions values ('STr05', '11-07-2015', 'Sto05', 'Cus04', 'April');

select * from SalesTransactions;

create table GameCD_sales
(	Game_id varchar(5),
	store_id char(5),
	trans_id char(5),
	salesyear int,
	salesmonth char(15),
	foreign key (Game_id) references Games,
	foreign key (store_id) references store,
	foreign key (trans_id) references SalesTransactions);

insert into GameCD_sales values ('Game1', 'Sto04', 'STr01', 2012, 'May');
insert into GameCD_sales values ('Game4', 'Sto05', 'STr03', 2013, 'May');
insert into GameCD_sales values ('Game5', 'Sto03', 'STr02', 2015, 'January');
insert into GameCD_sales values ('Game2', 'Sto01', 'STr05', 2015, 'July');
insert into GameCD_sales values ('Game3', 'Sto02', 'STr04', 2015, 'May');

create table Games
(
	Game_id varchar(5) primary key,
	Game_category varchar(25),
	Game_name varchar(25),
	price varchar(10),
	vendor_id char(5),
	foreign key (vendor_id) references vendor,
	division_id char(5),
	foreign key (division_id) references Division
);

insert into Games values ('Game1', 'Race', 'ABCD', '�20.89', 'Ven04', 'DRace');
insert into Games values ('Game2', 'Action Game', 'ZXCV', '�34.00', 'Ven05', 'DActG');
insert into Games values ('Game3', 'Education Game', 'XYZFG', '�140.25', 'Ven01', 'DEduG');
insert into Games values ('Game4', 'Strategy Game', 'QWERTY', '�29.99', 'Ven03', 'DStrG');
insert into Games values ('Game5', 'Sports Game', 'TYUJNF', '�15.89', 'Ven02', 'DSpoG');

select * from Games;
