use GamingCDStoreFT
go

SELECT G.Game_id, G.Game_name, S.region_id, G.price, C.cust_name, C.cust_gender
FROM Games G, Customer C, TempSales T, store S
WHERE G.Game_id = T.Game_id AND
	  C.cust_key = T.cust_key AND
	  S.store_key = T.store_key AND 
	  C.cust_name LIKE 'A%'; 

SELECT G.Game_id, G.Game_name, S.region_id, G.price, C.cust_name, C.cust_gender, ca.trans_date
FROM Games G, Customer C, TempSales T, store S, Calendar ca
WHERE G.Game_id = T.Game_id AND
	  C.cust_key = T.cust_key AND
	  S.store_key = T.store_key AND 
	  ca.cal_key = T.cal_key AND
	  ca.trans_date >= '09-01-2015';

SELECT G.Game_id, G.Game_name, S.region_id, G.price, C.cust_name, C.cust_gender
FROM Games G, Customer C, TempSales T, store S
WHERE G.Game_id = T.Game_id AND
	  C.cust_key = T.cust_key AND
	  S.store_key = T.store_key AND
	  G.price >= '�34.00';
