use GamingCDStoreFT
go

create table Calendar
(
	cal_key int NOT NULL IDENTITY primary key,
	Game_id varchar(5),
	month char(20),
	trans_date date
);

INSERT INTO calendar(Game_id, month, trans_date)
SELECT trans_id, month, trans_date FROM GamingCDStore.dbo.SalesTransactions;

create table Games
(
	Game_key int NOT NULL IDENTITY primary key,
	Game_id varchar(5),
	Game_name varchar(25),
	price varchar(10),
	vendor_id char(5),
	division_id char(5)
);

insert into Games(Game_id, Game_name, price, vendor_id, division_id)
select Game_id, Game_name, price, vendor_id, division_id from GamingCDStore.dbo.Games;

create table store
(
	store_key int NOT NULL IDENTITY primary key,
	store_id char(5),
	store_zipcode char(5),
	region_id char(5)
);

insert into store (store_id, store_zipcode, region_id)
select store_id, store_zipcode, region_id from GamingCDStore.dbo.store;

create table Customer
(
	cust_key int NOT NULL IDENTITY primary key,
	cust_id char(5),
	cust_name  char(15),
	cust_gender char(6),
	cust_address varchar (20),
	zipcode char(2)
);

insert into Customer (cust_id, cust_name, cust_gender, cust_address,zipcode)
select cust_id, cust_name, cust_gender, cust_address,zipcode from GamingCDStore.dbo.Customer;

create table Sales_FT
(
	cal_key int,
	foreign key (cal_key) references Calendar(cal_key),
	Game_key int,
	foreign key (Game_key) references Games(Game_key),
	store_key int,
	foreign key (store_key) references store(store_key),
	cust_key int,
	foreign key (cust_key) references Customer(cust_key),
	trans_id char(5),
	price varchar(10),
	Game_name varchar(25),
	cust_name  char(15),
	primary key(Game_key, trans_id)
);

CREATE TABLE TempSales ( 
store_key INT,
Game_key INT,
cust_key INT,
cal_key INT,
store_id char(5),
Game_id varchar(5),
cust_id char(5),
trans_id char(5),
trans_date date,
month char(20),
price varchar(10));

INSERT INTO TempSales(store_id, Game_id,cust_id,trans_id,trans_date,month,price)
(SELECT GamingCDStore.dbo.SalesTransactions.store_id, GamingCDStore.dbo.Games.Game_id, GamingCDStore.dbo.SalesTransactions.cust_id, 
GamingCDStore.dbo.SalesTransactions.trans_id, GamingCDStore.dbo.SalesTransactions.trans_date, 
GamingCDStore.dbo.SalesTransactions.month, GamingCDStore.dbo.Games.price
 FROM GamingCDStore.dbo.SalesTransactions
INNER JOIN GamingCDStore.dbo.GameCD_sales ON
GamingCDStore.dbo.SalesTransactions.trans_id = GamingCDStore.dbo.GameCD_sales.trans_id
INNER JOIN GamingCDStore.dbo.Games ON
GamingCDStore.dbo.GameCD_sales.Game_id = GamingCDStore.dbo.Games.Game_id);

UPDATE TempSales SET store_key = (SELECT store_key FROM store WHERE TempSales.store_id = store.store_id);
UPDATE TempSales SET  cust_key = (SELECT cust_key FROM Customer WHERE TempSales.cust_id = Customer.cust_id);
UPDATE TempSales SET Game_key = (SELECT Game_key FROM Games WHERE TempSales.Game_id = Games.Game_id);
UPDATE TempSales SET cal_key = (SELECT cal_key FROM Calendar WHERE TempSales.Game_id = Calendar.Game_id);

select * from TempSales;